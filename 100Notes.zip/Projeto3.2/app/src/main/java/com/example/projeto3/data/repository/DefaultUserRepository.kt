package com.example.projeto3.data.repository

import com.example.projeto3.data.dao.UserDao
import com.example.projeto3.data.entity.User

class DefaultUserRepository(private val userDao: UserDao) : UserRepository {
    
    override suspend fun registerUser(username: String, email: String, password: String): Result<User> {
        return try {
            // Check if username already exists
            if (isUsernameExists(username)) {
                return Result.Error("Username already exists")
            }
            
            // Check if email already exists
            if (isEmailExists(email)) {
                return Result.Error("Email already exists")
            }
            
            // Create new user
            val user = User(
                username = username,
                email = email,
                password = password // In a real app, this should be hashed
            )
            
            val userId = userDao.insertUser(user)
            val createdUser = user.copy(id = userId.toInt())
            
            Result.Success(createdUser)
        } catch (e: Exception) {
            Result.Error("Failed to register user: ${e.message}")
        }
    }
    
    override suspend fun authenticateUser(identifier: String, password: String): Result<User> {
        return try {
            val user = userDao.authenticateUser(identifier, password)
            if (user != null) {
                Result.Success(user)
            } else {
                Result.Error("Invalid username/email or password")
            }
        } catch (e: Exception) {
            Result.Error("Authentication failed: ${e.message}")
        }
    }
    
    override suspend fun getUserByUsername(username: String): User? {
        return try {
            userDao.getUserByUsername(username)
        } catch (e: Exception) {
            null
        }
    }
    
    override suspend fun updateUser(user: User) {
        userDao.updateUser(user)
    }
    
    override suspend fun isUsernameExists(username: String): Boolean {
        return userDao.isUsernameExists(username) > 0
    }
    
    override suspend fun isEmailExists(email: String): Boolean {
        return userDao.isEmailExists(email) > 0
    }
}