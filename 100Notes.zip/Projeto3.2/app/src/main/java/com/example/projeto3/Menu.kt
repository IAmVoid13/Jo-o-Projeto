package com.example.projeto3

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SortByAlpha
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow

import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.projeto3.ui.theme.Projeto3Theme
import com.example.projeto3.viewmodel.NoteViewModel
import com.example.projeto3.model.SortOption as ModelSortOption
import com.example.projeto3.data.entity.Note
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import com.example.projeto3.model.SortOption

@Composable
fun NoteCard(
    title: String,
    date: String,
    dueDate: String,
    content: String,
    modifier: Modifier = Modifier,
    noteId: Int = 0,
    onClick: (Int) -> Unit = {}
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .height(120.dp)
            .padding(horizontal = 16.dp),
        shape = RoundedCornerShape(8.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color(0xFFF5F5F5)
        ),
        onClick = { onClick(noteId) }
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            // Title row with due date on the right
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF0D47A1),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Due: $dueDate",
                    fontSize = 14.sp,
                    color = Color(0xFFE57373), // Light red color for due date
                    fontWeight = FontWeight.Medium
                )
            }
            
            // Creation date
            Text(
                text = "Created: $date",
                fontSize = 14.sp,
                color = Color.Gray,
                modifier = Modifier.padding(top = 4.dp)
            )
            
            // Note content
            Text(
                text = content,
                fontSize = 14.sp,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(top = 8.dp)
            )
        }
    }
}



@Composable
fun SortOptionItem(
    icon: ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary
        )
        Spacer(modifier = Modifier.width(16.dp))
        Column(
            modifier = Modifier.weight(1f)
        ) {
            Text(
                text = title,
                fontWeight = FontWeight.Medium,
                fontSize = 16.sp
            )
            Text(
                text = subtitle,
                fontSize = 14.sp,
                color = Color.Gray
            )
        }
    }
}

@Composable
fun SortOptionsDialog(
    onDismiss: () -> Unit,
    onSortOptionSelected: (ModelSortOption) -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .shadow(8.dp)
                .clip(RoundedCornerShape(16.dp)),
            color = MaterialTheme.colorScheme.surface
        ) {
            Column(
                modifier = Modifier.padding(vertical = 8.dp)
            ) {
                Text(
                    text = "Sort Notes By",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    modifier = Modifier.padding(16.dp)
                )
                
                Divider()
                
                SortOptionItem(
                    icon = Icons.Filled.SortByAlpha,
                    title = "Alphabetical (A-Z)",
                    subtitle = "Sort notes by title in ascending order",
                    onClick = { 
                        onSortOptionSelected(SortOption.ALPHABETICAL_ASC)
                        onDismiss()
                    }
                )
                
                Divider(modifier = Modifier.padding(horizontal = 16.dp))
                
                SortOptionItem(
                    icon = Icons.Filled.SortByAlpha,
                    title = "Alphabetical (Z-A)",
                    subtitle = "Sort notes by title in descending order",
                    onClick = { 
                        onSortOptionSelected(SortOption.ALPHABETICAL_DESC)
                        onDismiss()
                    }
                )
                
                Divider(modifier = Modifier.padding(horizontal = 16.dp))
                
                SortOptionItem(
                    icon = Icons.Filled.ArrowDownward,
                    title = "Newest First",
                    subtitle = "Sort notes by creation date (newest to oldest)",
                    onClick = { 
                        onSortOptionSelected(SortOption.DATE_CREATED_NEWEST)
                        onDismiss()
                    }
                )
                
                Divider(modifier = Modifier.padding(horizontal = 16.dp))
                
                SortOptionItem(
                    icon = Icons.Filled.ArrowUpward,
                    title = "Oldest First",
                    subtitle = "Sort notes by creation date (oldest to newest)",
                    onClick = { 
                        onSortOptionSelected(SortOption.DATE_CREATED_OLDEST)
                        onDismiss()
                    }
                )
                
                Divider(modifier = Modifier.padding(horizontal = 16.dp))
                
                SortOptionItem(
                    icon = Icons.Filled.CalendarToday,
                    title = "Due Date (Soonest First)",
                    subtitle = "Sort notes by due date (soonest first)",
                    onClick = { 
                        onSortOptionSelected(SortOption.DUE_DATE_SOONEST)
                        onDismiss()
                    }
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MenuScreen(
    onNavigateToNewNote: () -> Unit,
    onNavigateToAccount: () -> Unit,
    onNavigateToSettings: () -> Unit = {},
    onNoteClick: (Int) -> Unit = {},
    viewModel: NoteViewModel? = null
) {
    var showSortOptions by remember { mutableStateOf(false) }
    
    // Get current logged in user from UserSession (now observable)
    val currentUser = UserSession.currentUser
    
    // Update current user in ViewModel when screen loads
    LaunchedEffect(currentUser) {
        viewModel?.updateCurrentUser()
    }
    
    // Collect notes and sort option from ViewModel
    val notes by viewModel?.notes?.collectAsState() ?: remember { mutableStateOf(emptyList<Note>()) }
    val currentSortOption by viewModel?.currentSortOption?.collectAsState() ?: remember { mutableStateOf(SortOption.DATE_CREATED_NEWEST) }
    
    // Function to handle sort option selection
    fun handleSortOptionSelected(option: SortOption) {
        viewModel?.setSortOption(option)
    }
    
    Scaffold(
        topBar = {
            TopAppBar(
                title = { 
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "100Notes",
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF0D47A1),
                            fontSize = 20.sp
                        )
                    }
                },
                actions = {
                    IconButton(onClick = { showSortOptions = true }) {
                        Icon(
                            imageVector = Icons.Filled.Settings,
                            contentDescription = "Sort Options"
                        )
                    }
                    IconButton(onClick = { UserSession.logout() }) {
                        Icon(
                            imageVector = Icons.Filled.Logout,
                            contentDescription = "Logout"
                        )
                    }
                }
            )
        },
        bottomBar = {
            BottomNavBar(
                currentRoute = NavRoutes.MENU,
                onMenuClick = { /* Already on Menu screen */ },
                onNewNoteClick = onNavigateToNewNote,
                onAccountClick = onNavigateToAccount
            )
        }
    ) { innerPadding ->
        Box(modifier = Modifier.fillMaxSize()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Debug info (can be removed in production)
                Text(
                    text = "Status: ${if (currentUser != null) "Logged in as $currentUser" else "Not logged in"}",
                    fontSize = 10.sp,
                    color = Color.Gray,
                    modifier = Modifier.padding(4.dp)
                )
                
                // Display current sort option
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Sorted by: ",
                        fontSize = 14.sp,
                        color = Color.Gray
                    )
                    Text(
                        text = when(currentSortOption) {
                            SortOption.ALPHABETICAL_ASC -> "Alphabetical (A-Z)"
                            SortOption.ALPHABETICAL_DESC -> "Alphabetical (Z-A)"
                            SortOption.DATE_CREATED_NEWEST -> "Newest First"
                            SortOption.DATE_CREATED_OLDEST -> "Oldest First"
                            SortOption.DUE_DATE_SOONEST -> "Due Date (Soonest First)"
                        },
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
                
                Text(
                    text = "Your Notes",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(vertical = 16.dp),
                    textAlign = TextAlign.Center
                )
                
                // Debug: Show notes count and ViewModel state
                Text(
                    text = "Debug: Found ${notes.size} notes for user '$currentUser'",
                    fontSize = 10.sp,
                    color = Color.Blue,
                    modifier = Modifier.padding(4.dp)
                )
                Text(
                    text = "ViewModel user: '${viewModel?.getCurrentUserId() ?: "null"}'",
                    fontSize = 10.sp,
                    color = Color.Magenta,
                    modifier = Modifier.padding(4.dp)
                )
                
                // Debug: Manual refresh button
                Button(
                    onClick = { 
                        viewModel?.updateCurrentUser()
                    },
                    modifier = Modifier.padding(4.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFFFF9800)
                    )
                ) {
                    Text("Refresh Notes", fontSize = 12.sp)
                }
                
                // Display notes from database
                if (notes.isEmpty()) {
                    // Show message when no notes exist
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "No notes yet",
                            fontSize = 18.sp,
                            color = Color.Gray,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Create your first note using the + button below",
                            fontSize = 14.sp,
                            color = Color.Gray,
                            textAlign = TextAlign.Center
                        )
                    }
                } else {
                    // Display notes in a LazyColumn
                    LazyColumn(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(notes) { note ->
                            NoteCard(
                                title = note.title,
                                date = Note.formatDate(note.creationDate),
                                dueDate = Note.formatDate(note.dueDate),
                                content = note.content,
                                noteId = note.id,
                                onClick = onNoteClick
                            )
                        }
                    }
                }
            }
            
            // Show sort options dialog when showSortOptions is true
            if (showSortOptions) {
                SortOptionsDialog(
                    onDismiss = { showSortOptions = false },
                    onSortOptionSelected = { option -> handleSortOptionSelected(option) }
                )
            }
        }
    }
}

