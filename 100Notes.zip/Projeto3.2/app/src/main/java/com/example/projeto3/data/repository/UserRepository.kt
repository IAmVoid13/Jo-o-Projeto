package com.example.projeto3.data.repository

import com.example.projeto3.data.entity.User

interface UserRepository {
    suspend fun registerUser(username: String, email: String, password: String): Result<User>
    suspend fun authenticateUser(identifier: String, password: String): Result<User>
    suspend fun getUserByUsername(username: String): User?
    suspend fun updateUser(user: User)
    suspend fun isUsernameExists(username: String): Boolean
    suspend fun isEmailExists(email: String): Boolean
}

sealed class Result<out T> {
    data class Success<out T>(val data: T) : Result<T>()
    data class Error(val message: String) : Result<Nothing>()
}