package com.example.projeto3

object NavRoutes {
    const val MENU = "menu"
    const val NEW_NOTE = "new_note"
    const val ACCOUNT = "account"
    const val VIEW_NOTE = "view_note"
    const val EDIT_NOTE = "edit_note"
}