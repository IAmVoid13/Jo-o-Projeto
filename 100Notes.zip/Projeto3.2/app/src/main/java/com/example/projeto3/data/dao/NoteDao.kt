package com.example.projeto3.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.projeto3.data.entity.Note
import kotlinx.coroutines.flow.Flow


/**
 * Data Access Object for the notes table
 */
@Dao
interface NoteDao {
    
    /**
     * Get all notes for a specific user
     */
    @Query("SELECT * FROM notes WHERE userId = :userId")
    fun getAllNotesForUser(userId: String): Flow<List<Note>>
    
    /**
     * Get a specific note by ID
     */
    @Query("SELECT * FROM notes WHERE id = :noteId")
    suspend fun getNoteById(noteId: Int): Note?
    
    /**
     * Insert a new note
     */
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNote(note: Note): Long
    
    /**
     * Update an existing note
     */
    @Update
    suspend fun updateNote(note: Note)
    
    /**
     * Delete a note
     */
    @Delete
    suspend fun deleteNote(note: Note)
    
    /**
     * Get notes sorted alphabetically (ascending)
     */
    @Query("SELECT * FROM notes WHERE userId = :userId ORDER BY title ASC")
    fun getNotesAlphabeticallyAsc(userId: String): Flow<List<Note>>
    
    /**
     * Get notes sorted alphabetically (descending)
     */
    @Query("SELECT * FROM notes WHERE userId = :userId ORDER BY title DESC")
    fun getNotesAlphabeticallyDesc(userId: String): Flow<List<Note>>
    
    /**
     * Get notes sorted by creation date (newest first)
     */
    @Query("SELECT * FROM notes WHERE userId = :userId ORDER BY creationDate DESC")
    fun getNotesNewestFirst(userId: String): Flow<List<Note>>
    
    /**
     * Get notes sorted by creation date (oldest first)
     */
    @Query("SELECT * FROM notes WHERE userId = :userId ORDER BY creationDate ASC")
    fun getNotesOldestFirst(userId: String): Flow<List<Note>>
    
    /**
     * Get notes sorted by due date (soonest first)
     */
    @Query("SELECT * FROM notes WHERE userId = :userId AND dueDate IS NOT NULL ORDER BY dueDate ASC")
    fun getNotesByDueDateSoonest(userId: String): Flow<List<Note>>
    
    /**
     * Count notes for a specific user
     */
    @Query("SELECT COUNT(*) FROM notes WHERE userId = :userId")
    suspend fun countNotesForUser(userId: String): Int
}