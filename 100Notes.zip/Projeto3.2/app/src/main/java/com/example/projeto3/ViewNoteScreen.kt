package com.example.projeto3

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.projeto3.data.entity.Note
import com.example.projeto3.ui.theme.Projeto3Theme
import com.example.projeto3.viewmodel.NoteViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ViewNoteScreen(
    onNavigateToMenu: () -> Unit,
    onNavigateToAccount: () -> Unit,
    onNavigateToEditNote: () -> Unit = {},
    onDeleteNote: () -> Unit = {},
    viewModel: NoteViewModel,
    noteId: Int
) {
    // Observe the selected note
    val selectedNote by viewModel.selectedNote.collectAsStateWithLifecycle(null)
    val selectedNoteId by viewModel.selectedNoteId.collectAsStateWithLifecycle(null)
    
    // If the note isn't already selected, select it
    LaunchedEffect(noteId) {
        if (selectedNoteId != noteId) {
            viewModel.selectNote(noteId)
        }
    }
    
    // Extract note data
    val noteTitle = selectedNote?.title ?: "Ritalin"
    val noteCreationDate = selectedNote?.let { Note.formatDate(it.creationDate) } ?: "7/9/2025"
    val noteDueDate = selectedNote?.let { Note.formatDate(it.dueDate) } ?: "16/6/2025"
    val noteContent = selectedNote?.content ?: "Medication for ADHD"

    Scaffold(
        topBar = {
            TopAppBar(
                title = { 
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "100Notes",
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF0D47A1),
                            fontSize = 20.sp
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateToMenu) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = "Back to Menu"
                        )
                    }
                },
                actions = {
                    // Edit button
                    IconButton(onClick = onNavigateToEditNote) {
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = "Edit Note"
                        )
                    }
                    
                    // Delete button
                    IconButton(onClick = onDeleteNote) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Delete Note",
                            tint = Color(0xFFE57373) // Red color for delete icon
                        )
                    }
                }
            )
        },
        bottomBar = {
            // Custom bottom bar without the "New Note" button
            NavigationBar(
                modifier = Modifier.fillMaxWidth()
            ) {
                // Menu Button
                NavigationBarItem(
                    selected = false,
                    onClick = onNavigateToMenu,
                    icon = { Icon(Icons.Filled.ArrowBack, contentDescription = "Back to Menu") },
                    label = { }
                )
                
                // Empty space where the "New Note" button would be
                Spacer(modifier = Modifier.weight(1f))
                
                // Account Button
                NavigationBarItem(
                    selected = false,
                    onClick = onNavigateToAccount,
                    icon = { Icon(Icons.Filled.Person, contentDescription = "Account") },
                    label = { }
                )
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.Start
        ) {
            // Note title
            Text(
                text = noteTitle,
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF0D47A1)
            )
            
            Spacer(modifier = Modifier.height(8.dp))
            
            // Dates row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Creation date
                Text(
                    text = "Created: $noteCreationDate",
                    fontSize = 14.sp,
                    color = Color.Gray
                )
                
                // Due date
                Text(
                    text = "Due: $noteDueDate",
                    fontSize = 14.sp,
                    color = Color(0xFFE57373) // Light red color for due date
                )
            }
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Divider
            Divider(color = Color.LightGray, thickness = 1.dp)
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Note content
            Text(
                text = noteContent,
                fontSize = 16.sp,
                lineHeight = 24.sp
            )
        }
    }
}

@Composable
fun ViewNoteScreenPreview() {
    Projeto3Theme {
        ViewNoteScreen(
            onNavigateToMenu = {},
            onNavigateToAccount = {},
            onNavigateToEditNote = {},
            onDeleteNote = {}
        )
    }
}

fun ViewNoteScreen(
    onNavigateToMenu: () -> kotlin.Unit,
    onNavigateToAccount: () -> kotlin.Unit,
    onNavigateToEditNote: () -> kotlin.Unit,
    onDeleteNote: () -> kotlin.Unit
) {
}
