package com.example.projeto3

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.projeto3.ui.theme.Projeto3Theme
import com.example.projeto3.viewmodel.UserViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AccountScreen(
    onNavigateToMenu: () -> Unit,
    onNavigateToNewNote: () -> Unit,
    userViewModel: UserViewModel? = null
) {
    // Collect ViewModel states
    val authState by userViewModel?.authState?.collectAsState() ?: remember { mutableStateOf(UserViewModel.AuthState.Idle) }
    val currentUser by userViewModel?.currentUser?.collectAsState() ?: remember { mutableStateOf(null) }
    val isLoadingUser by userViewModel?.isLoadingUser?.collectAsState() ?: remember { mutableStateOf(false) }
    
    // Observe UserSession state changes
    val sessionUser by UserSession.currentUserState
    val isUserLoggedIn = sessionUser != null
    
    // Screen states
    var showSignUpForm by remember { mutableStateOf(false) }
    var showLoginForm by remember { mutableStateOf(false) }
    var showUserProfile by remember { mutableStateOf(isUserLoggedIn) }
    var showEditProfile by remember { mutableStateOf(false) }
    
    // Validation states (moved here to be available in LaunchedEffect)
    var emailError by remember { mutableStateOf(false) }
    var passwordMatchError by remember { mutableStateOf(false) }
    var loginIdentifierError by remember { mutableStateOf(false) }
    var loginPasswordError by remember { mutableStateOf(false) }
    var loginError by remember { mutableStateOf(false) }
    var signUpError by remember { mutableStateOf(false) }
    var authErrorMessage by remember { mutableStateOf("") }
    
    // Handle auth state changes
    LaunchedEffect(authState) {
        when (authState) {
            is UserViewModel.AuthState.Success -> {
                showUserProfile = true
                showSignUpForm = false
                showLoginForm = false
                loginError = false
                signUpError = false
                userViewModel?.clearAuthState()
            }
            is UserViewModel.AuthState.Error -> {
                if (showLoginForm) {
                    loginError = true
                } else if (showSignUpForm) {
                    signUpError = true
                }
                authErrorMessage = (authState as UserViewModel.AuthState.Error).message
                // Clear the auth state after showing error
                userViewModel?.clearAuthState()
            }
            else -> {}
        }
    }
    
    // Sign up form fields
    var username by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    
    // Login form fields
    var loginIdentifier by remember { mutableStateOf("") }
    var loginPassword by remember { mutableStateOf("") }
    
    // Initialize user profile data based on current logged in user from database
    var userProfileUsername by remember { mutableStateOf("") }
    var userProfileEmail by remember { mutableStateOf("") }
    var userProfilePassword by remember { mutableStateOf("") }
    
    // Update profile data when current user changes
    LaunchedEffect(currentUser) {
        currentUser?.let { user ->
            userProfileUsername = user.username
            userProfileEmail = user.email
            userProfilePassword = user.password
            // Ensure we show the profile when user data is loaded
            if (!showUserProfile && sessionUser != null) {
                showUserProfile = true
            }
        }
    }
    
    // Handle case where user is logged in but currentUser is null (still loading)
    LaunchedEffect(sessionUser, currentUser, isLoadingUser) {
        if (sessionUser != null && currentUser == null && !isLoadingUser) {
            // User is logged in but data not loaded yet, load it
            userViewModel?.loadCurrentUser()
        } else if (sessionUser == null) {
            // User is not logged in, reset everything
            showUserProfile = false
            userProfileUsername = ""
            userProfileEmail = ""
            userProfilePassword = ""
        }
    }
    
    // Temporary edit fields
    var editUsername by remember { mutableStateOf("") }
    var editEmail by remember { mutableStateOf("") }
    var editPassword by remember { mutableStateOf("") }
    
    // Validate email format
    fun isValidEmail(email: String): Boolean {
        return email.contains("@") && 
               email.indexOf("@") > 0 && 
               email.contains(".com") && 
               email.indexOf(".com") > email.indexOf("@") + 1
    }
    
    // Validate password match
    fun doPasswordsMatch(): Boolean {
        return password == confirmPassword
    }
    
    // Validate sign up form
    fun validateSignUpForm(): Boolean {
        emailError = !isValidEmail(email)
        passwordMatchError = !doPasswordsMatch()
        
        return !emailError && !passwordMatchError && username.isNotEmpty() && password.isNotEmpty()
    }
    
    // Validate login form
    fun validateLoginForm(): Boolean {
        loginIdentifierError = loginIdentifier.isBlank()
        loginPasswordError = loginPassword.isBlank()
        
        return !loginIdentifierError && !loginPasswordError
    }
    
    // Handle sign up submission
    fun handleSignUp() {
        if (validateSignUpForm()) {
            userViewModel?.registerUser(username, email, password)
            
            // Reset form
            username = ""
            email = ""
            password = ""
            confirmPassword = ""
        }
    }
    
    // Handle login submission
    fun handleLogin() {
        if (validateLoginForm()) {
            userViewModel?.authenticateUser(loginIdentifier, loginPassword)
            
            // Reset form
            loginIdentifier = ""
            loginPassword = ""
        }
    }
    
    // Handle edit profile
    fun startEditProfile() {
        editUsername = userProfileUsername
        editEmail = userProfileEmail
        editPassword = userProfilePassword
        showEditProfile = true
    }
    
    // Save profile changes
    fun saveProfileChanges() {
        userProfileUsername = editUsername
        userProfileEmail = editEmail
        userProfilePassword = editPassword
        showEditProfile = false
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { 
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "100Notes",
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF0D47A1),
                            fontSize = 20.sp
                        )
                    }
                }
            )
        },
        bottomBar = {
            BottomNavBar(
                currentRoute = NavRoutes.ACCOUNT,
                onMenuClick = onNavigateToMenu,
                onNewNoteClick = onNavigateToNewNote,
                onAccountClick = { /* Already on Account screen */ }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            if (showUserProfile) {
                // Check if user data is still loading
                if (isUserLoggedIn && isLoadingUser) {
                    // Show loading indicator while user data is being loaded
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        CircularProgressIndicator(
                            color = Color(0xFF0D47A1)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "Loading your profile...",
                            fontSize = 16.sp,
                            color = Color.Gray
                        )
                    }
                } else if (isUserLoggedIn && currentUser == null && !isLoadingUser) {
                    // User is logged in but no user data found (user might have been deleted from database)
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = "User data not found",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.Red
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "Your session will be cleared. Please log in again.",
                            fontSize = 14.sp,
                            color = Color.Gray,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(
                            onClick = { 
                                UserSession.logout()
                                showUserProfile = false
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFF0D47A1)
                            )
                        ) {
                            Text("OK")
                        }
                    }
                } else if (showEditProfile) {
                    // Edit Profile Form
                    Text(
                        text = "Edit Your Profile",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center
                    )
                    
                    Spacer(modifier = Modifier.height(24.dp))
                    
                    // Username field
                    OutlinedTextField(
                        value = editUsername,
                        onValueChange = { editUsername = it },
                        label = { Text("Username") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    
                    Spacer(modifier = Modifier.height(16.dp))
                    
                    // Email field
                    OutlinedTextField(
                        value = editEmail,
                        onValueChange = { editEmail = it },
                        label = { Text("Email") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email)
                    )
                    
                    Spacer(modifier = Modifier.height(16.dp))
                    
                    // Password field
                    OutlinedTextField(
                        value = editPassword,
                        onValueChange = { editPassword = it },
                        label = { Text("Password") },
                        modifier = Modifier.fillMaxWidth(),
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        singleLine = true
                    )
                    
                    Spacer(modifier = Modifier.height(32.dp))
                    
                    // Buttons row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        // Cancel button (grey)
                        Button(
                            onClick = { showEditProfile = false },
                            modifier = Modifier
                                .weight(1f)
                                .height(56.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color.Gray
                            )
                        ) {
                            Text("Cancel", fontSize = 16.sp)
                        }
                        
                        // Save button (dark blue)
                        Button(
                            onClick = { saveProfileChanges() },
                            modifier = Modifier
                                .weight(1f)
                                .height(56.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFF0D47A1) // Dark blue color
                            )
                        ) {
                            Text("Save Changes", fontSize = 16.sp)
                        }
                    }
                } else {
                    // User Profile Display
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        // Edit button (pencil icon)
                        IconButton(
                            onClick = { startEditProfile() }
                        ) {
                            Icon(
                                imageVector = Icons.Default.Edit,
                                contentDescription = "Edit Profile",
                                tint = Color(0xFF0D47A1)
                            )
                        }
                    }
                    
                    // User icon
                    Icon(
                        imageVector = Icons.Default.Person,
                        contentDescription = "User Profile",
                        modifier = Modifier.size(120.dp),
                        tint = Color(0xFF0D47A1)
                    )
                    
                    Spacer(modifier = Modifier.height(24.dp))
                    
                    // Username
                    Text(
                        text = userProfileUsername,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center
                    )
                    
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    // Email
                    Text(
                        text = userProfileEmail,
                        fontSize = 16.sp,
                        color = Color.Gray,
                        textAlign = TextAlign.Center
                    )
                    
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    // Password (masked)
                    Text(
                        text = "Password: " + "*".repeat(userProfilePassword.length),
                        fontSize = 16.sp,
                        color = Color.Gray,
                        textAlign = TextAlign.Center
                    )
                    
                    Spacer(modifier = Modifier.height(32.dp))
                    
                    // Log out button
                    Button(
                        onClick = { 
                            showUserProfile = false
                            userViewModel?.logout()
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(56.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color.Gray
                        )
                    ) {
                        Text("Log Out", fontSize = 16.sp)
                    }
                }
            } else if (!showSignUpForm && !showLoginForm) {
                // Initial screen with sign up and login buttons
                Text(
                    text = "Welcome to Your Account",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
                
                Spacer(modifier = Modifier.height(16.dp))
                
                Text(
                    text = "Please sign up or log in to continue",
                    fontSize = 16.sp,
                    textAlign = TextAlign.Center,
                    color = Color.Gray
                )
                
                Spacer(modifier = Modifier.height(32.dp))
                
                // Sign Up Button (Grey)
                Button(
                    onClick = { showSignUpForm = true },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color.Gray
                    )
                ) {
                    Text(
                        text = "Sign Up",
                        fontSize = 16.sp
                    )
                }
                
                Spacer(modifier = Modifier.height(16.dp))
                
                // Log In Button (Blue)
                Button(
                    onClick = { showLoginForm = true },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF0D47A1) // Dark blue color
                    )
                ) {
                    Text(
                        text = "Log In",
                        fontSize = 16.sp
                    )
                }
            } else if (showSignUpForm) {
                // Sign Up Form
                Text(
                    text = "Create Your Account",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
                
                Spacer(modifier = Modifier.height(24.dp))
                
                // Username field
                OutlinedTextField(
                    value = username,
                    onValueChange = { username = it },
                    label = { Text("Username") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                
                Spacer(modifier = Modifier.height(16.dp))
                
                // Email field with validation
                OutlinedTextField(
                    value = email,
                    onValueChange = { 
                        email = it
                        if (it.isNotEmpty()) {
                            emailError = !isValidEmail(it)
                        }
                    },
                    label = { Text("Email") },
                    modifier = Modifier.fillMaxWidth(),
                    isError = emailError,
                    supportingText = {
                        if (emailError) {
                            Text(
                                text = "Please enter a valid email (example@domain.com)",
                                color = Color.Red
                            )
                        }
                    },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email)
                )
                
                Spacer(modifier = Modifier.height(16.dp))
                
                // Password field
                OutlinedTextField(
                    value = password,
                    onValueChange = { 
                        password = it
                        if (confirmPassword.isNotEmpty()) {
                            passwordMatchError = !doPasswordsMatch()
                        }
                    },
                    label = { Text("Password") },
                    modifier = Modifier.fillMaxWidth(),
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    singleLine = true
                )
                
                Spacer(modifier = Modifier.height(16.dp))
                
                // Confirm Password field with validation
                OutlinedTextField(
                    value = confirmPassword,
                    onValueChange = { 
                        confirmPassword = it
                        passwordMatchError = !doPasswordsMatch()
                    },
                    label = { Text("Confirm Password") },
                    modifier = Modifier.fillMaxWidth(),
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    isError = passwordMatchError,
                    supportingText = {
                        if (passwordMatchError) {
                            Text(
                                text = "Passwords do not match",
                                color = Color.Red
                            )
                        }
                    },
                    singleLine = true
                )
                
                // Show sign up error if any
                if (signUpError && authErrorMessage.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = authErrorMessage,
                        color = Color.Red,
                        fontSize = 14.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                
                Spacer(modifier = Modifier.height(32.dp))
                
                // Buttons row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Cancel button (grey)
                    Button(
                        onClick = { 
                            showSignUpForm = false
                            // Reset form
                            username = ""
                            email = ""
                            password = ""
                            confirmPassword = ""
                        },
                        modifier = Modifier
                            .weight(1f)
                            .height(56.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color.Gray
                        )
                    ) {
                        Text("Cancel", fontSize = 16.sp)
                    }
                    
                    // Create Account button (dark blue)
                    Button(
                        onClick = { handleSignUp() },
                        modifier = Modifier
                            .weight(1f)
                            .height(56.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF0D47A1) // Dark blue color
                        )
                    ) {
                        Text("Create Account", fontSize = 16.sp)
                    }
                }
            } else if (showLoginForm) {
                // Login Form
                Text(
                    text = "Log In to Your Account",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
                
                Spacer(modifier = Modifier.height(24.dp))
                
                // Username/Email field
                OutlinedTextField(
                    value = loginIdentifier,
                    onValueChange = { 
                        loginIdentifier = it
                        if (it.isNotEmpty()) {
                            loginIdentifierError = false
                            loginError = false
                        }
                    },
                    label = { Text("Username/Email") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    isError = loginIdentifierError || loginError,
                    supportingText = {
                        if (loginIdentifierError) {
                            Text(
                                text = "Username or email is required",
                                color = Color.Red
                            )
                        }
                    }
                )
                
                Spacer(modifier = Modifier.height(16.dp))
                
                // Password field
                OutlinedTextField(
                    value = loginPassword,
                    onValueChange = { 
                        loginPassword = it
                        if (it.isNotEmpty()) {
                            loginPasswordError = false
                            loginError = false
                        }
                    },
                    label = { Text("Password") },
                    modifier = Modifier.fillMaxWidth(),
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    singleLine = true,
                    isError = loginPasswordError || loginError,
                    supportingText = {
                        if (loginPasswordError) {
                            Text(
                                text = "Password is required",
                                color = Color.Red
                            )
                        } else if (loginError) {
                            Text(
                                text = if (authErrorMessage.isNotEmpty()) authErrorMessage else "Invalid username or password",
                                color = Color.Red
                            )
                        }
                    }
                )
                
                Spacer(modifier = Modifier.height(32.dp))
                
                // Buttons row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Cancel button (grey)
                    Button(
                        onClick = { 
                            showLoginForm = false
                            // Reset form
                            loginIdentifier = ""
                            loginPassword = ""
                            loginError = false
                        },
                        modifier = Modifier
                            .weight(1f)
                            .height(56.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color.Gray
                        )
                    ) {
                        Text("Cancel", fontSize = 16.sp)
                    }
                    
                    // Login button (dark blue)
                    Button(
                        onClick = { handleLogin() },
                        modifier = Modifier
                            .weight(1f)
                            .height(56.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF0D47A1) // Dark blue color
                        )
                    ) {
                        Text("Log In", fontSize = 16.sp)
                    }
                }
            }
        }
    }
}


@Composable
fun AccountScreenPreview() {
    Projeto3Theme {
        AccountScreen(
            onNavigateToMenu = {},
            onNavigateToNewNote = {}
        )
    }
}

