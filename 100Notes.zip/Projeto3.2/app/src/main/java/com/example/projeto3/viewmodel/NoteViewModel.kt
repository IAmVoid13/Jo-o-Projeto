package com.example.projeto3.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.projeto3.UserSession
import com.example.projeto3.data.entity.Note
import com.example.projeto3.data.repository.NoteRepository
import com.example.projeto3.model.SortOption
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.Date

/**
 * ViewModel for handling note-related operations and UI state
 */
open class NoteViewModel(private val repository: NoteRepository) : ViewModel() {
    
    // Current sort option
    private val _currentSortOption = MutableStateFlow(SortOption.DATE_CREATED_NEWEST)
    val currentSortOption: StateFlow<SortOption> = _currentSortOption
    
    // Currently selected note ID
    private val _selectedNoteId = MutableStateFlow<Int?>(null)
    val selectedNoteId: StateFlow<Int?> = _selectedNoteId
    
    // Currently selected note
    private val _selectedNote = MutableStateFlow<Note?>(null)
    val selectedNote: StateFlow<Note?> = _selectedNote
    
    // Current user ID flow - now reactive to UserSession changes
    private val _currentUserId = MutableStateFlow(UserSession.currentUser ?: "")
    
    // Update user ID when needed
    fun updateCurrentUser() {
        val newUserId = UserSession.currentUser ?: ""
        if (_currentUserId.value != newUserId) {
            _currentUserId.value = newUserId
            // Debug: Log user change
            println("NoteViewModel: User changed from '${_currentUserId.value}' to '$newUserId'")
        }
    }
    
    // Debug function to get current user ID
    fun getCurrentUserId(): String = _currentUserId.value
    
    // All notes for the current user
    val notes = combine(
        _currentSortOption,
        _currentUserId
    ) { sortOption, userId ->
        if (userId.isNotEmpty()) {
            repository.getAllNotesForUser(userId, sortOption)
        } else {
            flowOf(emptyList())
        }
    }.flatMapLatest { it }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )
    
    /**
     * Set the current sort option
     */
    fun setSortOption(sortOption: SortOption) {
        _currentSortOption.value = sortOption
    }
    
    /**
     * Select a note by ID
     */
    fun selectNote(noteId: Int) {
        _selectedNoteId.value = noteId
        viewModelScope.launch {
            _selectedNote.value = repository.getNoteById(noteId)
        }
    }
    
    /**
     * Clear the selected note
     */
    fun clearSelectedNote() {
        _selectedNoteId.value = null
        _selectedNote.value = null
    }
    
    /**
     * Create a new note
     */
    fun createNote(title: String, content: String, dueDate: Date?) {
        val userId = UserSession.currentUser ?: return
        viewModelScope.launch {
            repository.createNote(title, content, dueDate, userId)
        }
    }
    
    /**
     * Update an existing note
     */
    fun updateNote(noteId: Int, title: String, content: String, dueDate: Date?) {
        val userId = UserSession.currentUser ?: return
        viewModelScope.launch {
            repository.updateNote(noteId, title, content, dueDate, userId)
        }
    }
    
    /**
     * Delete a note
     */
    fun deleteNote(noteId: Int) {
        viewModelScope.launch {
            repository.deleteNote(noteId)
            if (_selectedNoteId.value == noteId) {
                clearSelectedNote()
            }
        }
    }
    
    /**
     * Factory for creating NoteViewModel instances
     */
    class Factory(private val repository: NoteRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(NoteViewModel::class.java)) {
                return NoteViewModel(repository) as T
            }
            throw IllegalArgumentException("Unknown ViewModel class")
        }
    }
}