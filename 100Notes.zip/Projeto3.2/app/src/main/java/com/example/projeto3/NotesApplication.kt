package com.example.projeto3

import android.app.Application
import com.example.projeto3.data.AppDatabase
import com.example.projeto3.data.repository.DefaultNoteRepository
import com.example.projeto3.data.repository.DefaultUserRepository
import com.example.projeto3.data.repository.NoteRepository
import com.example.projeto3.data.repository.UserRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.Calendar
import java.util.Date

/**
 * Application class for initializing app-wide components
 */
class NotesApplication : Application() {
    
    // Database instance
    private val database by lazy { AppDatabase.getDatabase(this) }
    
    // Repository instances
    val repository: NoteRepository by lazy { DefaultNoteRepository(database.noteDao()) }
    val userRepository: UserRepository by lazy { DefaultUserRepository(database.userDao()) }
    
    override fun onCreate() {
        super.onCreate()
        
        // Initialize UserSession with application context
        UserSession.initialize(this)
        
        // Initialize sample data
        CoroutineScope(Dispatchers.IO).launch {
            initializeSampleData()
        }
    }
    
    private suspend fun initializeSampleData() {
        val noteDao = database.noteDao()
        
        // Check if there are any notes for LFerreira user
        val lFerreiraNoteCount = noteDao.countNotesForUser("LFerreira")
        
        // If no notes exist for LFerreira, create the sample note
        if (lFerreiraNoteCount == 0) {
            repository.createNote(
                title = "Ritalin",
                content = "Medication for ADHD",
                dueDate = Calendar.getInstance().apply {
                    set(2024, Calendar.JUNE, 16, 0, 0, 0)
                    set(Calendar.MILLISECOND, 0)
                }.time,
                userId = "LFerreira"
            )
        }
        
        // Check if there are any notes for FSilva user
        val fSilvaNoteCount = noteDao.countNotesForUser("FSilva")
        
        // If no notes exist for FSilva, create sample notes
        if (fSilvaNoteCount == 0) {
            repository.createNote(
                title = "Meeting Notes",
                content = "Discussed project timeline and assigned tasks to team members. Follow-up meeting scheduled for next week.",
                dueDate = Calendar.getInstance().apply {
                    set(2024, Calendar.MAY, 15, 0, 0, 0)
                    set(Calendar.MILLISECOND, 0)
                }.time,
                userId = "FSilva"
            )
            
            repository.createNote(
                title = "Shopping List",
                content = "Groceries: milk, bread, eggs, fruits. Don't forget to buy birthday gift for mom.",
                dueDate = Calendar.getInstance().apply {
                    set(2024, Calendar.APRIL, 20, 0, 0, 0)
                    set(Calendar.MILLISECOND, 0)
                }.time,
                userId = "FSilva"
            )
            
            repository.createNote(
                title = "Book Review",
                content = "Finished reading 'The Clean Code'. Great insights on writing maintainable software. Need to apply these principles in current project.",
                dueDate = null,
                userId = "FSilva"
            )
        }
    }
}