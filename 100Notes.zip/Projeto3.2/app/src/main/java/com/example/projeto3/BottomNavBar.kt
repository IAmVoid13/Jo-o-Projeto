package com.example.projeto3

import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.example.projeto3.ui.theme.Projeto3Theme

@Composable
fun BottomNavBar(
    currentRoute: String,
    onMenuClick: () -> Unit,
    onNewNoteClick: () -> Unit,
    onAccountClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    NavigationBar(
        modifier = modifier.fillMaxWidth()
    ) {
        // Menu Button (with house icon)
        NavigationBarItem(
            selected = currentRoute == NavRoutes.MENU,
            onClick = onMenuClick,
            icon = { Icon(Icons.Filled.Home, contentDescription = "Home") },
            label = { }
        )
        
        // Add Button (with plus icon)
        NavigationBarItem(
            selected = currentRoute == NavRoutes.NEW_NOTE,
            onClick = onNewNoteClick,
            icon = { Icon(Icons.Default.Add, contentDescription = "Add New Note") },
            label = { }
        )
        
        // Account Button
        NavigationBarItem(
            selected = currentRoute == NavRoutes.ACCOUNT,
            onClick = onAccountClick,
            icon = { Icon(Icons.Filled.Person, contentDescription = "Account") },
            label = { }
        )
    }
}


@Composable
fun BottomNavBarPreview() {
    Projeto3Theme {
        BottomNavBar(
            currentRoute = NavRoutes.MENU,
            onMenuClick = {},
            onNewNoteClick = {},
            onAccountClick = {}
        )
    }
}