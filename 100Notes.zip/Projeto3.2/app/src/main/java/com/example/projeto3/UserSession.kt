package com.example.projeto3

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue

/**
 * Singleton object to manage user session information across the app
 */
object UserSession {
    private const val PREFS_NAME = "user_session"
    private const val KEY_CURRENT_USER = "current_user"
    
    private var sharedPreferences: SharedPreferences? = null
    
    // Current logged in user (null if no user is logged in) - now observable
    private var _currentUser = mutableStateOf<String?>(null)
    var currentUser: String? by _currentUser
    
    // Expose the state for Compose observation
    val currentUserState get() = _currentUser
    
    /**
     * Initialize the UserSession with application context
     * This should be called from the Application class
     */
    fun initialize(context: Context) {
        if (sharedPreferences == null) {
            sharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            // Load the saved user session only if currentUser is not already set
            if (currentUser == null) {
                currentUser = sharedPreferences?.getString(KEY_CURRENT_USER, null)
            }
        }
    }
    
    /**
     * Log in a user
     * @param username The username of the user to log in
     */
    fun login(username: String) {
        currentUser = username
        // Save to SharedPreferences
        sharedPreferences?.edit()?.apply {
            putString(KEY_CURRENT_USER, username)
            apply()
        }
    }
    
    /**
     * Log out the current user
     */
    fun logout() {
        currentUser = null
        // Remove from SharedPreferences
        sharedPreferences?.edit()?.apply {
            remove(KEY_CURRENT_USER)
            apply()
        }
    }
    
    /**
     * Check if a user is logged in
     * @return true if a user is logged in, false otherwise
     */
    fun isLoggedIn(): Boolean {
        return currentUser != null
    }
    
    /**
     * Check if the current user is LFerreira
     * @return true if the current user is LFerreira, false otherwise
     */
    fun isLFerreira(): Boolean {
        return currentUser == "LFerreira"
    }
}