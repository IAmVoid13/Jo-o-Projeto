package com.example.projeto3.model

/**
 * Enum representing different sort options for notes
 */
enum class SortOption {
    ALPHABETICAL_ASC,
    ALPHABETICAL_DESC,
    DATE_CREATED_NEWEST,
    DATE_CREATED_OLDEST,
    DUE_DATE_SOONEST
}