package com.example.projeto3.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.text.SimpleDateFormat
import java.util.*

/**
 * Entity representing a note in the database
 */
@Entity(tableName = "notes")
data class Note(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val title: String,
    val content: String,
    val creationDate: Date,
    val dueDate: Date?,
    val userId: String // To associate notes with users
) {
    companion object {
        private val dateFormatter = SimpleDateFormat("MMMM d", Locale.getDefault())
        
        /**
         * Format a Date to a user-friendly string
         */
        fun formatDate(date: Date?): String {
            return date?.let { dateFormatter.format(it) } ?: ""
        }
    }
}