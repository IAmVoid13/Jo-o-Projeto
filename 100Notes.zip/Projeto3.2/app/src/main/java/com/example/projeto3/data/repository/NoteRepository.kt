package com.example.projeto3.data.repository

import com.example.projeto3.data.dao.NoteDao
import com.example.projeto3.data.entity.Note
import com.example.projeto3.model.SortOption
import kotlinx.coroutines.flow.Flow
import java.util.Date

/**
 * Repository interface for handling note-related data operations
 */
interface NoteRepository {
    /**
     * Get all notes for a user with the specified sort option
     */
    fun getAllNotesForUser(userId: String, sortOption: SortOption): Flow<List<Note>>
    
    /**
     * Get a note by ID
     */
    suspend fun getNoteById(noteId: Int): Note?
    
    /**
     * Create a new note
     */
    suspend fun createNote(
        title: String,
        content: String,
        dueDate: Date?,
        userId: String
    ): Long
    
    /**
     * Update an existing note
     */
    suspend fun updateNote(
        noteId: Int,
        title: String,
        content: String,
        dueDate: Date?,
        userId: String
    )
    
    /**
     * Delete a note
     */
    suspend fun deleteNote(noteId: Int)
}

/**
 * Default implementation of NoteRepository
 */
class DefaultNoteRepository(private val noteDao: NoteDao) : NoteRepository {
    
    override fun getAllNotesForUser(userId: String, sortOption: SortOption): Flow<List<Note>> {
        return when (sortOption) {
            SortOption.ALPHABETICAL_ASC -> noteDao.getNotesAlphabeticallyAsc(userId)
            SortOption.ALPHABETICAL_DESC -> noteDao.getNotesAlphabeticallyDesc(userId)
            SortOption.DATE_CREATED_NEWEST -> noteDao.getNotesNewestFirst(userId)
            SortOption.DATE_CREATED_OLDEST -> noteDao.getNotesOldestFirst(userId)
            SortOption.DUE_DATE_SOONEST -> noteDao.getNotesByDueDateSoonest(userId)
        }
    }
    
    override suspend fun getNoteById(noteId: Int): Note? {
        return noteDao.getNoteById(noteId)
    }
    
    override suspend fun createNote(
        title: String,
        content: String,
        dueDate: Date?,
        userId: String
    ): Long {
        val note = Note(
            title = title,
            content = content,
            creationDate = Date(),
            dueDate = dueDate,
            userId = userId
        )
        return noteDao.insertNote(note)
    }
    
    override suspend fun updateNote(
        noteId: Int,
        title: String,
        content: String,
        dueDate: Date?,
        userId: String
    ) {
        val existingNote = noteDao.getNoteById(noteId)
        existingNote?.let {
            val updatedNote = it.copy(
                title = title,
                content = content,
                dueDate = dueDate
            )
            noteDao.updateNote(updatedNote)
        }
    }
    
    override suspend fun deleteNote(noteId: Int) {
        val note = noteDao.getNoteById(noteId)
        note?.let {
            noteDao.deleteNote(it)
        }
    }
}