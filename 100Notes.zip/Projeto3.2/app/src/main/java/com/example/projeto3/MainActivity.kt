package com.example.projeto3

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.projeto3.ui.theme.Projeto3Theme
import com.example.projeto3.viewmodel.NoteViewModel
import com.example.projeto3.viewmodel.UserViewModel
import com.example.projeto3.viewmodel.UserViewModelFactory

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        
        // UserSession is now initialized in NotesApplication and will restore saved login state
        
        setContent {
            Projeto3Theme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    AppNavigation()
                }
            }
        }
    }
}

@Composable
fun AppNavigation() {
    val navController = rememberNavController()
    val application = (androidx.compose.ui.platform.LocalContext.current.applicationContext as NotesApplication)
    val noteViewModel: NoteViewModel = viewModel(
        factory = NoteViewModel.Factory(application.repository)
    )
    val userViewModel: UserViewModel = viewModel(
        factory = UserViewModelFactory(application.userRepository)
    )
    
    NavHost(
        navController = navController,
        startDestination = NavRoutes.MENU
    ) {
        composable(NavRoutes.MENU) {
            MenuScreen(
                onNavigateToNewNote = { navController.navigate(NavRoutes.NEW_NOTE) },
                onNavigateToAccount = { navController.navigate(NavRoutes.ACCOUNT) },
                onNoteClick = { noteId ->
                    noteViewModel.selectNote(noteId)
                    navController.navigate("${NavRoutes.VIEW_NOTE}/$noteId")
                },
                viewModel = noteViewModel
            )
        }
        
        composable(NavRoutes.NEW_NOTE) {
            NewNoteScreen(
                onNavigateToMenu = { navController.navigate(NavRoutes.MENU) },
                onNavigateToAccount = { navController.navigate(NavRoutes.ACCOUNT) },
                viewModel = noteViewModel
            )
        }
        
        composable(NavRoutes.ACCOUNT) {
            AccountScreen(
                onNavigateToMenu = { navController.navigate(NavRoutes.MENU) },
                onNavigateToNewNote = { navController.navigate(NavRoutes.NEW_NOTE) },
                userViewModel = userViewModel
            )
        }
        
        composable(
            route = "${NavRoutes.VIEW_NOTE}/{noteId}",
            arguments = listOf(navArgument("noteId") { type = NavType.IntType })
        ) { backStackEntry ->
            val noteId = backStackEntry.arguments?.getInt("noteId") ?: 0
            ViewNoteScreen(
                onNavigateToMenu = { navController.navigate(NavRoutes.MENU) },
                onNavigateToAccount = { navController.navigate(NavRoutes.ACCOUNT) },
                onNavigateToEditNote = { 
                    navController.navigate("${NavRoutes.EDIT_NOTE}/$noteId") 
                },
                onDeleteNote = {
                    noteViewModel.deleteNote(noteId)
                    navController.navigate(NavRoutes.MENU)
                },
                viewModel = noteViewModel,
                noteId = noteId
            )
        }
        
        composable(
            route = "${NavRoutes.EDIT_NOTE}/{noteId}",
            arguments = listOf(navArgument("noteId") { type = NavType.IntType })
        ) { backStackEntry ->
            val noteId = backStackEntry.arguments?.getInt("noteId") ?: 0
            EditNoteScreen(
                onNavigateBack = { navController.popBackStack() },
                onNavigateToMenu = { navController.navigate(NavRoutes.MENU) },
                viewModel = noteViewModel,
                noteId = noteId
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditNoteScreen(
    onNavigateBack: () -> Boolean,
    onNavigateToMenu: () -> Unit,
    viewModel: NoteViewModel,
    noteId: Int
) {
    // Observe the selected note
    val selectedNote by viewModel.selectedNote.collectAsStateWithLifecycle(null)
    val selectedNoteId by viewModel.selectedNoteId.collectAsStateWithLifecycle(null)
    
    // If the note isn't already selected, select it
    LaunchedEffect(noteId) {
        if (selectedNoteId != noteId) {
            viewModel.selectNote(noteId)
        }
    }
    
    // State variables for editing
    var title by remember { mutableStateOf("") }
    var monthExpanded by remember { mutableStateOf(false) }
    var selectedMonth by remember { mutableStateOf("") }
    var dayText by remember { mutableStateOf("") }
    var isValidDay by remember { mutableStateOf(true) }
    var additionalInfo by remember { mutableStateOf("") }
    
    // Time variables
    var dueHour by remember { mutableStateOf("") }
    var dueMinute by remember { mutableStateOf("") }
    var isValidTime by remember { mutableStateOf(true) }
    
    // Error states
    var titleError by remember { mutableStateOf(false) }
    var monthError by remember { mutableStateOf(false) }
    var dayError by remember { mutableStateOf(false) }
    var timeError by remember { mutableStateOf(false) }
    var additionalInfoError by remember { mutableStateOf(false) }
    
    // Initialize fields when note is loaded
    LaunchedEffect(selectedNote) {
        selectedNote?.let { note ->
            title = note.title
            additionalInfo = note.content
            
            // Parse due date if available
            note.dueDate?.let { dueDate ->
                val calendar = java.util.Calendar.getInstance()
                calendar.time = dueDate
                
                val monthNames = arrayOf(
                    "January", "February", "March", "April", "May", "June",
                    "July", "August", "September", "October", "November", "December"
                )
                selectedMonth = monthNames[calendar.get(java.util.Calendar.MONTH)]
                dayText = calendar.get(java.util.Calendar.DAY_OF_MONTH).toString()
                
                // For simplicity, set time to 12:00 if not specified
                dueHour = "12"
                dueMinute = "00"
            }
        }
    }
    
    val months = listOf(
        "January", "February", "March", "April", "May", "June",
        "July", "August", "September", "October", "November", "December"
    )
    
    // Function to get the number of days in a month
    fun getDaysInMonth(month: String): Int {
        return when (month) {
            "February" -> 28
            "April", "June", "September", "November" -> 30
            "January", "March", "May", "July", "August", "October", "December" -> 31
            else -> 31
        }
    }
    
    // Validate the day input
    fun validateDay(day: String, month: String) {
        if (day.isBlank() || month.isBlank()) {
            isValidDay = true
            return
        }
        
        val dayInt = day.toIntOrNull()
        if (dayInt == null) {
            isValidDay = false
            return
        }
        
        val maxDays = getDaysInMonth(month)
        isValidDay = dayInt in 1..maxDays
    }
    
    // Validate time input
    fun validateTime(hour: String, minute: String) {
        if (hour.isBlank() || minute.isBlank()) {
            isValidTime = true
            return
        }
        
        val hourInt = hour.toIntOrNull()
        val minuteInt = minute.toIntOrNull()
        
        if (hourInt == null || minuteInt == null) {
            isValidTime = false
            return
        }
        
        isValidTime = hourInt in 0..23 && minuteInt in 0..59
    }
    
    // Validate all fields
    fun validateAllFields(): Boolean {
        titleError = title.isBlank()
        monthError = selectedMonth.isBlank()
        dayError = dayText.isBlank() || !isValidDay
        timeError = (dueHour.isBlank() || dueMinute.isBlank()) || !isValidTime
        additionalInfoError = additionalInfo.isBlank()
        
        return !titleError && !monthError && !dayError && !timeError && !additionalInfoError
    }
    
    // Handle update button click
    fun handleUpdateClick() {
        if (validateAllFields()) {
            // Create the due date from selected month, day, and current year
            val calendar = java.util.Calendar.getInstance()
            val currentYear = calendar.get(java.util.Calendar.YEAR)
            val monthNumber = months.indexOf(selectedMonth)
            val dayNumber = dayText.toIntOrNull() ?: 1
            
            val dueDate = try {
                calendar.set(currentYear, monthNumber, dayNumber)
                calendar.time
            } catch (e: Exception) {
                null
            }
            
            // Update the note using the ViewModel
            viewModel.updateNote(
                noteId = noteId,
                title = title,
                content = additionalInfo,
                dueDate = dueDate
            )
            
            // Navigate back after updating
            onNavigateBack()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { 
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Edit Note",
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF0D47A1),
                            fontSize = 20.sp
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = { onNavigateBack() }) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 8.dp, vertical = 8.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = title,
                onValueChange = { 
                    title = it
                    if (it.isNotEmpty()) titleError = false
                },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Title") },
                isError = titleError,
                supportingText = {
                    if (titleError) {
                        Text(
                            text = "Title is required",
                            color = Color.Red
                        )
                    } else {
                        Text("", modifier = Modifier.height(0.dp))
                    }
                }
            )
            
            Spacer(modifier = Modifier.height(4.dp))
            
            // Date section header
            Text(
                text = "Due Date",
                fontSize = 16.sp,
                fontWeight = FontWeight.Medium,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
            
            Spacer(modifier = Modifier.height(4.dp))
            
            // Month dropdown
            Box(
                modifier = Modifier.fillMaxWidth()
            ) {
                ExposedDropdownMenuBox(
                    expanded = monthExpanded,
                    onExpandedChange = { monthExpanded = it }
                ) {
                    OutlinedTextField(
                        value = selectedMonth,
                        onValueChange = {},
                        readOnly = true,
                        placeholder = { Text("Month") },
                        trailingIcon = {
                            ExposedDropdownMenuDefaults.TrailingIcon(expanded = monthExpanded)
                        },
                        colors = ExposedDropdownMenuDefaults.textFieldColors(),
                        modifier = Modifier
                            .fillMaxWidth()
                            .menuAnchor(),
                        isError = monthError,
                        supportingText = {
                            if (monthError) {
                                Text(
                                    text = "Month is required",
                                    color = Color.Red
                                )
                            }
                        }
                    )
                    
                    ExposedDropdownMenu(
                        expanded = monthExpanded,
                        onDismissRequest = { monthExpanded = false }
                    ) {
                        months.forEach { month ->
                            DropdownMenuItem(
                                text = { Text(month) },
                                onClick = {
                                    selectedMonth = month
                                    monthExpanded = false
                                    monthError = false
                                    validateDay(dayText, month)
                                }
                            )
                        }
                    }
                }
            }
            
            Spacer(modifier = Modifier.height(4.dp))
            
            // Day input field
            OutlinedTextField(
                value = dayText,
                onValueChange = { 
                    dayText = it
                    validateDay(it, selectedMonth)
                    if (it.isNotEmpty()) dayError = false
                },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Day") },
                isError = !isValidDay || dayError,
                supportingText = {
                    when {
                        dayError -> Text(
                            text = "Day is required",
                            color = Color.Red
                        )
                        !isValidDay -> Text(
                            text = "Invalid day",
                            color = Color.Red
                        )
                    }
                }
            )
            
            // Display max days info
            if (selectedMonth.isNotEmpty()) {
                Text(
                    text = "$selectedMonth has ${getDaysInMonth(selectedMonth)} days",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            
            Spacer(modifier = Modifier.height(4.dp))
            
            // Time input section
            Text(
                text = "Due Time",
                fontSize = 14.sp,
                color = MaterialTheme.colorScheme.primary
            )
            
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Hour input
                OutlinedTextField(
                    value = dueHour,
                    onValueChange = { 
                        if (it.length <= 2) {
                            dueHour = it
                            validateTime(it, dueMinute)
                            if (it.isNotEmpty()) timeError = false
                        }
                    },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("HH") },
                    singleLine = true,
                    isError = !isValidTime || timeError
                )
                
                Text(
                    text = ":",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 8.dp)
                )
                
                // Minute input
                OutlinedTextField(
                    value = dueMinute,
                    onValueChange = { 
                        if (it.length <= 2) {
                            dueMinute = it
                            validateTime(dueHour, it)
                            if (it.isNotEmpty()) timeError = false
                        }
                    },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("MM") },
                    singleLine = true,
                    isError = !isValidTime || timeError
                )
            }
            
            // Time error message
            if (timeError || !isValidTime) {
                Text(
                    text = if (timeError) "Time is required" else "Invalid time format",
                    color = Color.Red,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(start = 4.dp, top = 4.dp)
                )
            }
            
            // Time format hint
            Text(
                text = "Enter time in 24-hour format (00-23:00-59)",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 4.dp)
            )
            
            Spacer(modifier = Modifier.height(4.dp))
            
            // Additional information section
            OutlinedTextField(
                value = additionalInfo,
                onValueChange = { 
                    additionalInfo = it
                    if (it.isNotEmpty()) additionalInfoError = false
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(100.dp),
                placeholder = { Text("Enter additional information here") },
                maxLines = 6,
                isError = additionalInfoError,
                supportingText = {
                    if (additionalInfoError) {
                        Text(
                            text = "Additional information is required",
                            color = Color.Red
                        )
                    } else {
                        Text("", modifier = Modifier.height(0.dp))
                    }
                }
            )
            
            // Buttons row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Cancel button (grey)
                Button(
                    onClick = { onNavigateBack() },
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color.Gray
                    )
                ) {
                    Text("Cancel", fontSize = 14.sp)
                }
                
                // Update button (dark blue)
                Button(
                    onClick = { handleUpdateClick() },
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF0D47A1)
                    )
                ) {
                    Text("Update", fontSize = 14.sp)
                }
            }
        }
    }
}


@Composable
fun AppPreview() {
    Projeto3Theme {
        AppNavigation()
    }
}