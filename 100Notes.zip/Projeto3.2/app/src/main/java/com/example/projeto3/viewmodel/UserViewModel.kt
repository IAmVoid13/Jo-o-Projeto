package com.example.projeto3.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.projeto3.UserSession
import com.example.projeto3.data.entity.User
import com.example.projeto3.data.repository.Result
import com.example.projeto3.data.repository.UserRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class UserViewModel(private val userRepository: UserRepository) : ViewModel() {
    
    private val _authState = MutableStateFlow<AuthState>(AuthState.Idle)
    val authState: StateFlow<AuthState> = _authState.asStateFlow()
    
    private val _currentUser = MutableStateFlow<User?>(null)
    val currentUser: StateFlow<User?> = _currentUser.asStateFlow()
    
    private val _isLoadingUser = MutableStateFlow(false)
    val isLoadingUser: StateFlow<Boolean> = _isLoadingUser.asStateFlow()
    
    sealed class AuthState {
        object Idle : AuthState()
        object Loading : AuthState()
        data class Success(val user: User) : AuthState()
        data class Error(val message: String) : AuthState()
    }
    
    fun registerUser(username: String, email: String, password: String) {
        viewModelScope.launch {
            _authState.value = AuthState.Loading
            
            when (val result = userRepository.registerUser(username, email, password)) {
                is Result.Success -> {
                    _authState.value = AuthState.Success(result.data)
                    _currentUser.value = result.data
                    UserSession.login(result.data.username)
                }
                is Result.Error -> {
                    _authState.value = AuthState.Error(result.message)
                }
            }
        }
    }
    
    fun authenticateUser(identifier: String, password: String) {
        viewModelScope.launch {
            _authState.value = AuthState.Loading
            
            when (val result = userRepository.authenticateUser(identifier, password)) {
                is Result.Success -> {
                    _authState.value = AuthState.Success(result.data)
                    _currentUser.value = result.data
                    UserSession.login(result.data.username)
                }
                is Result.Error -> {
                    _authState.value = AuthState.Error(result.message)
                }
            }
        }
    }
    
    fun logout() {
        UserSession.logout()
        _currentUser.value = null
        _authState.value = AuthState.Idle
    }
    
    fun clearAuthState() {
        _authState.value = AuthState.Idle
    }
    
    fun loadCurrentUser() {
        viewModelScope.launch {
            _isLoadingUser.value = true
            try {
                val currentUsername = UserSession.currentUser
                if (currentUsername != null) {
                    val user = userRepository.getUserByUsername(currentUsername)
                    if (user != null) {
                        _currentUser.value = user
                    } else {
                        // User not found in database, logout the session
                        UserSession.logout()
                        _currentUser.value = null
                    }
                } else {
                    _currentUser.value = null
                }
            } finally {
                _isLoadingUser.value = false
            }
        }
    }
}

class UserViewModelFactory(private val userRepository: UserRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(UserViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return UserViewModel(userRepository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}