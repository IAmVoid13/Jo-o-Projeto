package com.example.projeto3

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.projeto3.ui.theme.Projeto3Theme
import com.example.projeto3.viewmodel.NoteViewModel
import java.text.SimpleDateFormat

import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NewNoteScreen(
    onNavigateToMenu: () -> Unit,
    onNavigateToAccount: () -> Unit,
    viewModel: NoteViewModel
) {
    var title by remember { mutableStateOf("") }
    var monthExpanded by remember { mutableStateOf(false) }
    var selectedMonth by remember { mutableStateOf("") }
    var dayText by remember { mutableStateOf("") }
    var isValidDay by remember { mutableStateOf(true) }
    var additionalInfo by remember { mutableStateOf("") }
    
    // Time variables
    var dueHour by remember { mutableStateOf("") }
    var dueMinute by remember { mutableStateOf("") }
    var isValidTime by remember { mutableStateOf(true) }
    var showTimeDialog by remember { mutableStateOf(false) }
    
    // Error states
    var titleError by remember { mutableStateOf(false) }
    var monthError by remember { mutableStateOf(false) }
    var dayError by remember { mutableStateOf(false) }
    var timeError by remember { mutableStateOf(false) }
    var additionalInfoError by remember { mutableStateOf(false) }
    
    // Get current date and time for automatic creation date
    val currentDate = remember {
        val calendar = Calendar.getInstance()
        val dateFormat = SimpleDateFormat("MMMM dd, yyyy", Locale.getDefault())
        dateFormat.format(calendar.time)
    }
    
    val currentTime = remember {
        val calendar = Calendar.getInstance()
        val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())
        timeFormat.format(calendar.time)
    }
    
    // Get current month and day for display
    val currentMonth = remember {
        val calendar = Calendar.getInstance()
        SimpleDateFormat("MMMM", Locale.getDefault()).format(calendar.time)
    }
    
    val currentDay = remember {
        val calendar = Calendar.getInstance()
        SimpleDateFormat("dd", Locale.getDefault()).format(calendar.time)
    }
    
    val months = listOf(
        "January", "February", "March", "April", "May", "June",
        "July", "August", "September", "October", "November", "December"
    )
    
    // Function to get the number of days in a month
    fun getDaysInMonth(month: String): Int {
        return when (month) {
            "February" -> 28
            "April", "June", "September", "November" -> 30
            "January", "March", "May", "July", "August", "October", "December" -> 31
            else -> 31 // Default to 31 if no month is selected
        }
    }
    
    // Validate the day input
    fun validateDay(day: String, month: String) {
        if (day.isBlank() || month.isBlank()) {
            isValidDay = true
            return
        }
        
        val dayInt = day.toIntOrNull()
        if (dayInt == null) {
            isValidDay = false
            return
        }
        
        val maxDays = getDaysInMonth(month)
        isValidDay = dayInt in 1..maxDays
    }
    
    // Validate time input
    fun validateTime(hour: String, minute: String) {
        if (hour.isBlank() || minute.isBlank()) {
            isValidTime = true
            return
        }
        
        val hourInt = hour.toIntOrNull()
        val minuteInt = minute.toIntOrNull()
        
        if (hourInt == null || minuteInt == null) {
            isValidTime = false
            return
        }
        
        isValidTime = hourInt in 0..23 && minuteInt in 0..59
    }
    
    // Format time for display
    fun formatTime(hour: String, minute: String): String {
        if (hour.isBlank() || minute.isBlank()) return ""
        
        val hourInt = hour.toIntOrNull() ?: return ""
        val minuteInt = minute.toIntOrNull() ?: return ""
        
        return String.format("%02d:%02d", hourInt, minuteInt)
    }
    
    // Validate all fields
    fun validateAllFields(): Boolean {
        titleError = title.isBlank()
        monthError = selectedMonth.isBlank()
        dayError = dayText.isBlank() || !isValidDay
        timeError = (dueHour.isBlank() || dueMinute.isBlank()) || !isValidTime
        additionalInfoError = additionalInfo.isBlank()
        
        return !titleError && !monthError && !dayError && !timeError && !additionalInfoError
    }
    
    // Handle create button click
    fun handleCreateClick() {
        if (validateAllFields()) {
            // Create the due date from selected month, day, and current year
            val currentYear = Calendar.getInstance().get(Calendar.YEAR)
            val monthNumber = months.indexOf(selectedMonth) + 1 // Convert to 1-based month
            val dayNumber = dayText.toIntOrNull() ?: 1
            
            val dueDate = try {
                // Use Calendar instead of LocalDate for API level 24 compatibility
                val calendar = Calendar.getInstance()
                calendar.set(Calendar.YEAR, currentYear)
                calendar.set(Calendar.MONTH, monthNumber - 1) // Calendar months are 0-based
                calendar.set(Calendar.DAY_OF_MONTH, dayNumber)
                calendar.set(Calendar.HOUR_OF_DAY, 0)
                calendar.set(Calendar.MINUTE, 0)
                calendar.set(Calendar.SECOND, 0)
                calendar.set(Calendar.MILLISECOND, 0)
                calendar.time
            } catch (e: Exception) {
                null // If date creation fails, set to null
            }
            
            // Create the note using the ViewModel
            viewModel.createNote(
                title = title,
                content = additionalInfo,
                dueDate = dueDate
            )
            
            // Navigate back to menu after creating the note
            onNavigateToMenu()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { 
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "100Notes",
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF0D47A1),
                            fontSize = 20.sp
                        )
                    }
                }
            )
        },
        bottomBar = {
            BottomNavBar(
                currentRoute = NavRoutes.NEW_NOTE,
                onMenuClick = onNavigateToMenu,
                onNewNoteClick = { /* Already on NewNote screen */ },
                onAccountClick = onNavigateToAccount
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 8.dp, vertical = 8.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = title,
                onValueChange = { 
                    title = it
                    if (it.isNotEmpty()) titleError = false
                },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Title") },
                isError = titleError,
                supportingText = {
                    if (titleError) {
                        Text(
                            text = "Title is required",
                            color = Color.Red
                        )
                    } else {
                        // Empty text to reserve space
                        Text("", modifier = Modifier.height(0.dp))
                    }
                }
            )
            
            Spacer(modifier = Modifier.height(4.dp))
            
            // Date section header
            Text(
                text = "Date Information",
                fontSize = 16.sp,
                fontWeight = FontWeight.Medium,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
            
            Spacer(modifier = Modifier.height(4.dp))
            
            // Date section with creation date on left and due date on right
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Creation date section (left side - automatic)
                Column(
                    modifier = Modifier.weight(1f)
                ) {
                    Text(
                        text = "Creation Date (Automatic)",
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(bottom = 4.dp)
                    )
                    
                    // Display current date
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = MaterialTheme.shapes.small,
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        tonalElevation = 2.dp
                    ) {
                        Column(
                            modifier = Modifier.padding(8.dp)
                        ) {
                            // Date row
                            Row(
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.CalendarToday,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = currentDate,
                                    fontSize = 14.sp
                                )
                            }
                            
                            Spacer(modifier = Modifier.height(4.dp))
                            
                            // Time row
                            Row(
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.AccessTime,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = currentTime,
                                    fontSize = 14.sp
                                )
                            }
                        }
                    }
                }
                
                // Due date section (right side - user selected)
                Column(
                    modifier = Modifier.weight(1f)
                ) {
                    Text(
                        text = "Due Date (Select)",
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(bottom = 4.dp)
                    )
                    
                    // Month dropdown
                    Box(
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        ExposedDropdownMenuBox(
                            expanded = monthExpanded,
                            onExpandedChange = { monthExpanded = it }
                        ) {
                            OutlinedTextField(
                                value = selectedMonth,
                                onValueChange = {},
                                readOnly = true,
                                placeholder = { Text("Month") },
                                trailingIcon = {
                                    ExposedDropdownMenuDefaults.TrailingIcon(expanded = monthExpanded)
                                },
                                colors = ExposedDropdownMenuDefaults.textFieldColors(),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .menuAnchor(),
                                isError = monthError,
                                supportingText = {
                                    if (monthError) {
                                        Text(
                                            text = "Month is required",
                                            color = Color.Red
                                        )
                                    }
                                }
                            )
                            
                            ExposedDropdownMenu(
                                expanded = monthExpanded,
                                onDismissRequest = { monthExpanded = false }
                            ) {
                                months.forEach { month ->
                                    DropdownMenuItem(
                                        text = { Text(month) },
                                        onClick = {
                                            selectedMonth = month
                                            monthExpanded = false
                                            monthError = false
                                            // Validate day when month changes
                                            validateDay(dayText, month)
                                        }
                                    )
                                }
                            }
                        }
                    }
                    
                    Spacer(modifier = Modifier.height(4.dp))
                    
                    // Day input field
                    OutlinedTextField(
                        value = dayText,
                        onValueChange = { 
                            dayText = it
                            validateDay(it, selectedMonth)
                            if (it.isNotEmpty()) dayError = false
                        },
                        modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text("Day") },
                        isError = !isValidDay || dayError,
                        supportingText = {
                            when {
                                dayError -> Text(
                                    text = "Day is required",
                                    color = Color.Red
                                )
                                !isValidDay -> Text(
                                    text = "Invalid day",
                                    color = Color.Red
                                )
                            }
                        }
                    )
                    
                    // Display max days info
                    if (selectedMonth.isNotEmpty()) {
                        Text(
                            text = "$selectedMonth has ${getDaysInMonth(selectedMonth)} days",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    
                    Spacer(modifier = Modifier.height(4.dp))
                    
                    // Time input section
                    Text(
                        text = "Due Time",
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.primary
                    )
                    
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Hour input
                        OutlinedTextField(
                            value = dueHour,
                            onValueChange = { 
                                if (it.length <= 2) {
                                    dueHour = it
                                    validateTime(it, dueMinute)
                                    if (it.isNotEmpty()) timeError = false
                                }
                            },
                            modifier = Modifier.weight(1f),
                            placeholder = { Text("HH") },
                            singleLine = true,
                            isError = !isValidTime || timeError
                        )
                        
                        Text(
                            text = ":",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp)
                        )
                        
                        // Minute input
                        OutlinedTextField(
                            value = dueMinute,
                            onValueChange = { 
                                if (it.length <= 2) {
                                    dueMinute = it
                                    validateTime(dueHour, it)
                                    if (it.isNotEmpty()) timeError = false
                                }
                            },
                            modifier = Modifier.weight(1f),
                            placeholder = { Text("MM") },
                            singleLine = true,
                            isError = !isValidTime || timeError
                        )
                    }
                    
                    // Time error message
                    if (timeError || !isValidTime) {
                        Text(
                            text = if (timeError) "Time is required" else "Invalid time format",
                            color = Color.Red,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(start = 4.dp, top = 4.dp)
                        )
                    }
                    
                    // Time format hint
                    Text(
                        text = "Enter time in 24-hour format (00-23:00-59)",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }
            
            Spacer(modifier = Modifier.height(4.dp))
            
            // Additional information section
            OutlinedTextField(
                value = additionalInfo,
                onValueChange = { 
                    additionalInfo = it
                    if (it.isNotEmpty()) additionalInfoError = false
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(100.dp),
                placeholder = { Text("Enter additional information here") },
                maxLines = 6,
                isError = additionalInfoError,
                supportingText = {
                    if (additionalInfoError) {
                        Text(
                            text = "Additional information is required",
                            color = Color.Red
                        )
                    } else {
                        // Empty text to reserve space
                        Text("", modifier = Modifier.height(0.dp))
                    }
                }
            )
            
            // No spacer here to keep buttons closer to text field
            
            // Buttons row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Cancel button (grey)
                Button(
                    onClick = { onNavigateToMenu() },
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color.Gray
                    )
                ) {
                    Text("Cancel", fontSize = 14.sp)
                }
                
                // Create button (dark blue)
                Button(
                    onClick = { handleCreateClick() },
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF0D47A1) // Dark blue color
                    )
                ) {
                    Text("Create", fontSize = 14.sp)
                }
            }
        }
    }
}

